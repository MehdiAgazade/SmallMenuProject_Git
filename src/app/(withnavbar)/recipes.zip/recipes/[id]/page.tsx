"use client"

import { IRecipe } from '@/types/recipepage'
import axios from 'axios'
import { useParams } from 'next/navigation'
import React, { useEffect, useState } from 'react'

const RecipePage = () => {
    const {id} = useParams<{id: string}>()
    const endpoint = "https://dummyjson.com/recipes"
    const [recipeInfo, setRecipeInfo] = useState<IRecipe | null>(null)

    useEffect(() => {
        axios.get<IRecipe>(endpoint + id).then((res) => {
            setRecipeInfo(res.data)
        })
        .catch((err) => {
            console.log(err.response?.status)
            console.log(err.response?.data)
        })
    }, [id])

  return (
    <div>
        <p>Name: {recipeInfo?.name}</p>
        <p>Ingredients: {recipeInfo?.ingredients.join(",")}</p>
        <p>Instructions: {recipeInfo?.instructions.join(" ")}</p>
        <p>Cooking Time: {recipeInfo?.prepTimeMinutes}</p>
        <p>Rating: {recipeInfo?.rating}</p>
    </div>
  )
}

export default RecipePage
